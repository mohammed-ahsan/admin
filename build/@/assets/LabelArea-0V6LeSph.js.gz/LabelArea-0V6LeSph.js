import{j as e,e as t}from"./index-kaEKLpWB.js";const o=({label:s})=>e.jsx(t.Label,{className:"col-span-4 sm:col-span-2 font-medium text-sm",children:s});export{o as L};
