const s="/@/assets/forgot-password-office-CKN5V2s2.jpeg",o="/@/assets/forgot-password-office-CKN5V2s2.jpeg";export{s as I,o as a};
